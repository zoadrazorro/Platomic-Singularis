import googleLogo from "@/assets/logos/google.png";

export const GoogleLogo = () => {
  return <img src={googleLogo} alt="Google" />;
};
