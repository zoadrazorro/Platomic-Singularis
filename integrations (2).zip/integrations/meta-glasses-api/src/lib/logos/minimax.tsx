import minimaxLogo from "@/assets/logos/minimax.png";

export const MinimaxLogo = () => {
  return <img src={minimaxLogo} alt="Minimax" />;
};
